from django.apps import AppConfig
class InfotechConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'infotech'
